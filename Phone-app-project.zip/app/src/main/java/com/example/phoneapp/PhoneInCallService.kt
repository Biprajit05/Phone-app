package com.example.phoneapp

import android.telecom.Call
import android.telecom.InCallService

class PhoneInCallService : InCallService() {
    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        // The first prototype registers as an in-call service.
        // A dedicated in-call screen and robust call controls will be added in a later step.
    }
}
