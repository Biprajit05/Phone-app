package com.example.phoneapp

import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.telecom.TelecomManager
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var number: EditText
    private lateinit var proximity: Switch

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.WHITE
        window.navigationBarColor = android.graphics.Color.WHITE
        showDialer()
        if (intent?.data != null) number.setText(intent.data?.schemeSpecificPart ?: "")
    }

    private fun showDialer() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFFF7F8FA.toInt())
        }
        val title = TextView(this).apply {
            text = "Phone"
            textSize = 30f
            setTextColor(0xFF17202A.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 72))
        number = EditText(this).apply {
            hint = "Enter phone number"
            textSize = 24f
            gravity = Gravity.CENTER
            inputType = 3
            setSingleLine(true)
        }
        root.addView(number, LinearLayout.LayoutParams(-1, 64))
        val keys = listOf("1","2","3","4","5","6","7","8","9","*","0","#")
        val grid = GridLayout(this).apply { columnCount = 3 }
        keys.forEach { key ->
            val b = Button(this).apply {
                text = key; textSize = 22f
                setOnClickListener { number.append(key) }
            }
            grid.addView(b, ViewGroup.LayoutParams(0, 76))
            b.layoutParams = (b.layoutParams as GridLayout.LayoutParams).apply {
                width = 0; height = 76; columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            }
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 310))
        val call = Button(this).apply {
            text = "Call"
            textSize = 18f
            setOnClickListener { placeCall() }
        }
        root.addView(call, LinearLayout.LayoutParams(-1, 58))
        val role = Button(this).apply {
            text = "Set as default phone app"
            setOnClickListener { requestDialerRole() }
        }
        root.addView(role, LinearLayout.LayoutParams(-1, 54))
        proximity = Switch(this).apply {
            text = "Ignore proximity sensor (experimental)"
            textSize = 16f
            isChecked = getPreferences(Context.MODE_PRIVATE).getBoolean("ignore_proximity", false)
            setOnCheckedChangeListener { _, checked ->
                getPreferences(Context.MODE_PRIVATE).edit().putBoolean("ignore_proximity", checked).apply()
                Toast.makeText(this@MainActivity,
                    "Saved. Android may still control proximity behavior during calls.",
                    Toast.LENGTH_LONG).show()
            }
        }
        root.addView(proximity, LinearLayout.LayoutParams(-1, 64))
        val note = TextView(this).apply {
            text = "Note: Android does not provide ordinary apps a universal switch to disable the system proximity sensor. This setting is a prototype and does not yet override every phone's in-call screen behavior."
            textSize = 13f
            setTextColor(0xFF5B6573.toInt())
        }
        root.addView(note)
        setContentView(root)
    }

    private fun requestDialerRole() {
        val rm = getSystemService(RoleManager::class.java)
        if (rm.isRoleAvailable(RoleManager.ROLE_DIALER) && !rm.isRoleHeld(RoleManager.ROLE_DIALER)) {
            startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 100)
        } else Toast.makeText(this, "This app is already the default dialer, or the role is unavailable.", Toast.LENGTH_LONG).show()
    }

    private fun placeCall() {
        val digits = number.text.toString().trim()
        if (digits.isEmpty()) { Toast.makeText(this, "Enter a number first", Toast.LENGTH_SHORT).show(); return }
        try {
            val telecom = getSystemService(TELECOM_SERVICE) as TelecomManager
            telecom.placeCall(Uri.fromParts("tel", digits, null), Bundle())
        } catch (e: Exception) {
            startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", digits, null)))
        }
    }
}
