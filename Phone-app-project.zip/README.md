# Phone-app

An early Android dialer prototype built with Kotlin.

## Build
GitHub Actions builds a debug APK on pushes to `main` or when manually started from the Actions tab.

## Important proximity-sensor limitation
Android does not expose a universal public API for third-party apps to disable the system proximity sensor during calls. The current switch stores the user's preference and clearly labels the behavior experimental; it does not guarantee overriding device/OEM call-screen behavior.

This is an early prototype, not yet a replacement for the full system dialer. Contacts, call history, and a complete in-call UI will be developed in later steps.
